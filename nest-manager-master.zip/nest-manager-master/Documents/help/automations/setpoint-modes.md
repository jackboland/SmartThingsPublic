## <img src="https://raw.githubusercontent.com/tonesto7/nest-manager/master/Images/App/mode_setpoints_icon.png" width="32" height="32"> Thermostat Mode Setpoint Automations
Set Temp Setpoints based on ST Modes 

<img src="https://raw.githubusercontent.com/tonesto7/nest-manager/master/Images/Screenshots/App/AutomationApp/tstat_modes_1.png" width="281" height="500"><img src="https://raw.githubusercontent.com/tonesto7/nest-manager/develop/Images/Screenshots/App/AutomationApp/tstat_modes_2.png" width="281" height="500"><img src="https://raw.githubusercontent.com/tonesto7/nest-manager/develop/Images/Screenshots/App/AutomationApp/tstat_modes_3.png" width="281" height="500"><img src="https://raw.githubusercontent.com/tonesto7/nest-manager/develop/Images/Screenshots/App/AutomationApp/tstat_modes_4.png" width="281" height="500"><img src="https://raw.githubusercontent.com/tonesto7/nest-manager/develop/Images/Screenshots/App/AutomationApp/tstat_modes_5.png" width="281" height="500"><img src="https://raw.githubusercontent.com/tonesto7/nest-manager/develop/Images/Screenshots/App/AutomationApp/tstat_modes_6.png" width="281" height="500">


----------

