## <img src="https://raw.githubusercontent.com/tonesto7/nest-manager/master/Images/App/mode_automation_icon.png" width="32" height="32"> Presence Mode Automation
Change Nest Home/Away based on SmartThings Modes 

<img src="https://raw.githubusercontent.com/tonesto7/nest-manager/master/Images/Screenshots/App/AutomationApp/nest_mode_1.png" width="281" height="500"><img src="https://raw.githubusercontent.com/tonesto7/nest-manager/master/Images/Screenshots/App/AutomationApp/nest_mode_2.png" width="281" height="500"><img src="https://raw.githubusercontent.com/tonesto7/nest-manager/master/Images/Screenshots/App/AutomationApp/nest_mode_3.png" width="281" height="500"><img src="https://raw.githubusercontent.com/tonesto7/nest-manager/master/Images/Screenshots/App/AutomationApp/nest_mode_4.png" width="281" height="500"><img src="https://raw.githubusercontent.com/tonesto7/nest-manager/master/Images/Screenshots/App/AutomationApp/nest_mode_5.png" width="281" height="500"><img src="https://raw.githubusercontent.com/tonesto7/nest-manager/master/Images/Screenshots/App/AutomationApp/nest_mode_6.png" width="281" height="500">

* Select the SmartThings Modes to use to set the Nest Location to 'Home'
* Select the SmartThings Modes to use to set the Nest Location to 'Away'

----------