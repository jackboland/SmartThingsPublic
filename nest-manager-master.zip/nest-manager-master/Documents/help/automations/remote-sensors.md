## <img src="https://raw.githubusercontent.com/tonesto7/nest-manager/master/Images/App/remote_sensor_icon.png" width="32" height="32"> Remote Sensors
* No Documentation Available Yet.  I will update this once I finalize the app. 

--------
