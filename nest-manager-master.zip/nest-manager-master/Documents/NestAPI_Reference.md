## Nest API Reference  




#### JSON Examples:
https://developer.nest.com/documentation/api-reference

#### Thermostats Objects
https://developer.nest.com/documentation/cloud/how-to-thermostats-object/

#### Carbon - Smoke Detectors Objects
https://developer.nest.com/documentation/cloud/how-to-smoke-co-alarms-object/

#### Structure Objects
https://developer.nest.com/documentation/cloud/how-to-structures-object/
